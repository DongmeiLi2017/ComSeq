### R code from vignette source 'Combine.Rnw'
### Encoding: UTF-8

###################################################
### code chunk number 1: Combine.Rnw:40-42 (eval = FALSE)
###################################################
## source("http://bioconductor.org/biocLite.R")
## biocLite("Combine")


###################################################
### code chunk number 2: Combine.Rnw:48-49 (eval = FALSE)
###################################################
## library(Combine)


###################################################
### code chunk number 3: Combine.Rnw:58-65
###################################################
library(Combine)
bottomly_count <- read.table("http://bowtie-bio.sourceforge.net/recount/countTables/bottomly_count_table.txt", header=TRUE, sep = "\t")
head(bottomly_count)
label <- c(rep(0, 10), rep(1, 11))
Result <- Combined_method(RNAseqcount = bottomly_count, label = label, alpha = 0.05)
summary(Result)
Result


